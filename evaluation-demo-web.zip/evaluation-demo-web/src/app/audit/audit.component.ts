import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { AuditService, AuthenticationService } from '@/_services';
import { Subject } from 'rxjs';

@Component({ templateUrl: 'audit.component.html' })
export class AuditComponent implements OnInit {
   public audits: any[]
   public currentUser: any = {}
   public dtTrigger: Subject<any> = new Subject();
   public dtOptions: DataTables.Settings = {};
   public  hrs12 = true;
   public formatVal = '12'
    constructor(
        private authenticationService: AuthenticationService,
        private auditService: AuditService
    ) {
    }

    ngOnInit(): void {
        this.loadAllAudits();
        this.dtOptions = {
            pageLength: 10,
            processing: true
        }
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'))
    }
    private loadAllAudits() {
        this.auditService.getAll()
            .pipe(first())
            .subscribe(audits => {

                this.audits = audits
                this.dtTrigger.next();
                this.parseToNum()
            });

    }
    private parseToNum() {
        this.audits.forEach(ele => {
            ele.loginTime = parseInt(ele.loginTime)
            ele.logoutTime = parseInt(ele.logoutTime)
        })
    }
    public  changeTimeFormat() {
        if (this.formatVal == '12') {
            this.hrs12 = true
        } else if (this.formatVal == '24') {
            this.hrs12 = false
        }
    }
    public  ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

}